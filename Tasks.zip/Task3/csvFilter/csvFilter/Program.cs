﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Runtime.ConstrainedExecution;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using System.Threading;

namespace csvFilter
{
    internal class Program
    {
        public static void Main(string[] args)
        { 
                string[] csvLines = System.IO.File.ReadAllLines(@"C:\Users\ganes\OneDrive\Desktop\Linux\kubernetees\NET Technical Exercise\TechnicalTestData.csv");
                //create type of list
                var Fuel = new List<string>();
                var Make = new List<string>();
            int tNotMatch = 0;
                var CarRegistration = new List<string>();
                for (int i = 0; i < csvLines.Length; i++)
                {
                    string[] rowData = csvLines[i].Split(',');
                    Fuel.Add(rowData[4]);
                    Make.Add(rowData[1]);
                    CarRegistration.Add(rowData[0]);


                }
                Console.WriteLine("FUELTYPE:");
                for (int i = 1; i < Fuel.Count; i++)
                {
                    Console.WriteLine(Fuel[i]);

                }
                Console.ReadKey();

                Console.WriteLine("MAKE:");
                for (int i = 1; i < Make.Count; i++)
                {
                    Console.WriteLine(Make[i]);

                }
                Console.ReadKey();
                Console.WriteLine("CAR REGISTRATION:");
                Regex r1 = new Regex(@"\w{2}\d{2}\s\w{3}");
                
                for (int i = 0; i < CarRegistration.Count; i++){
                if (r1.IsMatch(CarRegistration[i]))
                {
                    Console.WriteLine("ISMATCHED");
                    Console.WriteLine(CarRegistration[i]);
                }
                else
                {
                    //CarRegistration.RemoveAt(i);
                    tNotMatch++;
                    Console.WriteLine("NOTMATCHED");


                }

                }

            Console.WriteLine("NotMatched Data ::"+tNotMatch);
                Console.ReadKey();
            }

        }
 
}