﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Anagram
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hello World!");

        }
        void Test()
        {
            string first = "anagram";
            string second = "gramana";

            IsAnagramSimple(first, second);
            IsAnagramFast(first, second);
        }


        private bool IsAnagramSimple(string first, string second)
        {
            return first.OrderBy(c => c).SequenceEqual(second.OrderBy(c => c));
        }

        private bool IsAnagramFast(string first, string second)
        {
            if (first.Length != second.Length)
            {
                return false;
            }

            var aFrequency = CalculateFrequency(first);
            var bFrequency = CalculateFrequency(second);

            foreach (var key in aFrequency.Keys)
            {
                if (!bFrequency.ContainsKey(key)) return false;
                if (aFrequency[key] != bFrequency[key]) return false;
            }

            return true;
        }

        private Dictionary<char, int> CalculateFrequency(string input)
        {
            var frequency = new Dictionary<char, int>();
            foreach (var c in input)
            {
                if (!frequency.ContainsKey(c))
                {
                    frequency.Add(c, 0);
                }
                ++frequency[c];
            }
            return frequency;
        }
    }
}