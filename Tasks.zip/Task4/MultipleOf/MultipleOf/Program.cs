﻿using System;

namespace MultipleOf
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PrintNumbers();
        }
        static void PrintNumbers() { 
         
            for (int i = 0; i < 100; i++)
                if (i % 3 == 0 && i % 5 == 0)
                { Console.WriteLine(i + "Fizzbuzz"); }
                else if (i % 3 == 0)
                { Console.WriteLine(i + "Fizz"); }
                else if (i % 5 == 0)
                { Console.WriteLine(i + "Buzz"); }
                else
                { Console.WriteLine(i); }
                }
        } 
} 

